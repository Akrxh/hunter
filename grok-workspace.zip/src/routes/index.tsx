import { createFileRoute } from "@tanstack/react-router";
import { HunterApp } from "@/components/hunter-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <HunterApp />;
}
