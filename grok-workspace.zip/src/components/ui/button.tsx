import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-display text-sm font-semibold tracking-wide uppercase transition-[background-color,color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]",
  {
    variants: {
      variant: {
        default:
          "bg-accent text-accent-fg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-accent)_70%,black)] hover:bg-accent-dim",
        outline:
          "bg-transparent text-fg shadow-[0_0_0_1px_var(--color-border)] hover:shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-accent)_55%,var(--color-border))] hover:text-accent-fg",
        ghost: "bg-transparent text-muted hover:text-fg hover:bg-surface-2",
        success: "bg-ok text-accent-fg hover:opacity-90",
      },
      size: {
        default: "h-11 rounded-sm px-4",
        sm: "h-9 rounded-sm px-3 text-xs",
        icon: "size-11 rounded-sm",
        "icon-sm": "size-9 rounded-sm",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    />
  );
}
