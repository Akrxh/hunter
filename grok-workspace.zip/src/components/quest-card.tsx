import {
  BookMarked,
  BookOpen,
  Check,
  Dumbbell,
  Pause,
  Play,
  RotateCcw,
} from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { HudFrame } from "@/components/hud-frame";
import { StripedBar } from "@/components/striped-bar";
import { Button } from "@/components/ui/button";
import { useHunterStore } from "@/lib/store";
import {
  elapsedNow,
  emptyQuest,
  ensureDay,
  formatClock,
  formatGoal,
  routine,
  todayKey,
  type QuestDef,
} from "@/lib/system";
import { cn } from "@/lib/utils";

const ICONS = {
  dumbbell: Dumbbell,
  book: BookOpen,
  play: Play,
  library: BookMarked,
} as const;

export function QuestCard({ quest, index }: { quest: QuestDef; index: number }) {
  const today = todayKey();
  const days = useHunterStore((s) => s.days);
  const startQuest = useHunterStore((s) => s.startQuest);
  const pauseQuest = useHunterStore((s) => s.pauseQuest);
  const resetQuest = useHunterStore((s) => s.resetQuest);
  const completeQuest = useHunterStore((s) => s.completeQuest);
  const uncompleteQuest = useHunterStore((s) => s.uncompleteQuest);
  const log = ensureDay(days, today).quests[quest.id] ?? emptyQuest();
  const running = Boolean(log.runningStartedAt);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, [running]);

  const elapsed = elapsedNow(log, now);
  const target = quest.durationMin * 60;
  const pct = log.completed ? 100 : Math.min(100, (elapsed / target) * 100);
  const Icon = ICONS[quest.icon];

  useEffect(() => {
    if (!running || log.completed) return;
    if (elapsed >= target) {
      completeQuest(quest.id);
      announce(quest);
    }
  }, [elapsed, running, log.completed, target, completeQuest, quest]);

  function onComplete() {
    if (log.completed) {
      uncompleteQuest(quest.id);
      return;
    }
    completeQuest(quest.id);
    announce(quest);
  }

  return (
    <HudFrame
      className={cn(
        "stagger-in flex h-full flex-col",
        log.completed && "bg-surface-2",
      )}
    >
      <div className="mb-4 flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="grid size-11 shrink-0 place-items-center rounded-sm bg-surface-2 text-accent shadow-hud">
            <Icon className="size-5" strokeWidth={1.75} />
          </span>
          <div>
            <p className="font-mono text-2xs uppercase tracking-hud text-accent">
              {quest.code} · {formatGoal(quest.durationMin)}
            </p>
            <h3 className="font-display text-xl font-semibold leading-tight tracking-tight text-fg">
              {quest.title}
            </h3>
            <p className="mt-0.5 text-sm text-muted">{quest.detail}</p>
          </div>
        </div>
        <span className="shrink-0 font-mono text-xs tabular-nums text-muted">
          +{quest.xp} XP
        </span>
      </div>

      <div className="mt-auto">
        <div className="mb-1.5 flex items-baseline justify-between font-mono text-2xs uppercase tracking-widest text-muted">
          <span>{log.completed ? "Cleared" : `Quest 0${index + 1}`}</span>
          <span className="tabular-nums text-fg">
            {formatClock(Math.min(elapsed, target))} / {formatClock(target)}
          </span>
        </div>
        <StripedBar value={pct} done={log.completed} className="h-2.5" />

        <div className="mt-4 flex flex-wrap gap-2">
          <Button
            type="button"
            variant={log.completed ? "outline" : "default"}
            onClick={onComplete}
            className={cn("min-w-28 flex-1", log.completed && "text-ok")}
          >
            <Check className="size-4" />
            {log.completed ? "Cleared" : "Complete"}
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => (running ? pauseQuest(quest.id) : startQuest(quest.id))}
            disabled={log.completed}
            className="min-w-24"
          >
            {running ? (
              <>
                <Pause className="size-4" /> Pause
              </>
            ) : (
              <>
                <Play className="size-4" /> Start
              </>
            )}
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => resetQuest(quest.id)}
            disabled={log.completed || (elapsed === 0 && !running)}
            aria-label="Reset timer"
          >
            <RotateCcw className="size-4" />
          </Button>
        </div>
      </div>
    </HudFrame>
  );
}

function announce(quest: QuestDef) {
  const state = useHunterStore.getState();
  const day = ensureDay(state.days, todayKey());
  if (day.bonusClaimed) {
    toast.success(`Daily quests cleared · +${quest.xp + routine.dailyClearBonus} XP`);
    return;
  }
  toast.success(`${quest.label} cleared · +${quest.xp} XP`);
}
