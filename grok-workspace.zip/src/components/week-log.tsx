import { HudFrame } from "@/components/hud-frame";
import { useHunterStore } from "@/lib/store";
import {
  ensureDay,
  parseKey,
  routine,
  todayKey,
  weekKeys,
} from "@/lib/system";
import { cn } from "@/lib/utils";

export function WeekLog() {
  const days = useHunterStore((s) => s.days);
  const today = todayKey();
  const keys = weekKeys(today);

  return (
    <HudFrame className="stagger-in">
      <div className="mb-4 flex items-end justify-between gap-3">
        <div>
          <p className="font-mono text-2xs uppercase tracking-hud text-accent">
            Seven-day log
          </p>
          <h2 className="font-display text-xl font-semibold tracking-tight">
            Recent gates
          </h2>
        </div>
        <p className="font-mono text-2xs uppercase tracking-widest text-faint">
          {routine.quests.length} quests / day
        </p>
      </div>
      <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
        {keys.map((key) => {
          const day = ensureDay(days, key);
          const done = routine.quests.filter(
            (q) => day.quests[q.id]?.completed,
          ).length;
          const isToday = key === today;
          const label = parseKey(key).toLocaleDateString(undefined, {
            weekday: "short",
          });
          const date = parseKey(key).getDate();
          return (
            <div
              key={key}
              className={cn(
                "flex flex-col items-center gap-2 rounded-md px-1 py-2.5 sm:px-2",
                isToday ? "bg-surface-2 shadow-hud-hover" : "bg-surface-2/60",
              )}
            >
              <span className="font-mono text-2xs uppercase tracking-widest text-faint">
                {label}
              </span>
              <span
                className={cn(
                  "font-display text-lg font-semibold tabular-nums leading-none",
                  isToday ? "text-fg" : "text-muted",
                )}
              >
                {date}
              </span>
              <div className="flex gap-0.5">
                {routine.quests.map((q) => (
                  <span
                    key={q.id}
                    className={cn(
                      "size-1.5 rounded-full",
                      day.quests[q.id]?.completed ? "bg-accent" : "bg-border",
                    )}
                  />
                ))}
              </div>
              <span className="font-mono text-2xs tabular-nums text-faint">
                {done}/{routine.quests.length}
              </span>
            </div>
          );
        })}
      </div>
    </HudFrame>
  );
}
