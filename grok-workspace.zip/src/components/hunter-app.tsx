import { useEffect } from "react";
import { Toaster } from "sonner";
import { DataTools } from "@/components/data-tools";
import { HazardStripe } from "@/components/hazard-stripe";
import { PlayerWindow } from "@/components/player-window";
import { QuestCard } from "@/components/quest-card";
import { RankUpModal } from "@/components/rank-up-modal";
import { WeekLog } from "@/components/week-log";
import { useHunterStore } from "@/lib/store";
import {
  dayFullyCleared,
  ensureDay,
  formatLongDate,
  routine,
  todayKey,
} from "@/lib/system";

export function HunterApp() {
  const hydrated = useHunterStore((s) => s.hydrated);
  const persistApi = useHunterStore.persist;

  useEffect(() => {
    void Promise.resolve(persistApi.rehydrate()).then(() => {
      useHunterStore.getState().hydrate();
    });
  }, [persistApi]);

  return (
    <div className="relative flex min-h-dvh flex-col">
      <HazardStripe animated />
      <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col gap-6 px-4 py-6 sm:px-6 sm:py-8">
        <Header />
        {hydrated ? <LoadedBoard /> : <BoardSkeleton />}
      </main>
      <footer className="mx-auto flex w-full max-w-6xl flex-col gap-3 px-4 pb-6 sm:flex-row sm:items-center sm:justify-between sm:px-6">
        <p className="max-w-xl text-sm text-faint">
          Goals live in JSON. Progress stays on this device — export a save
          file whenever you want a backup.
        </p>
        {hydrated ? <DataTools /> : null}
      </footer>
      <HazardStripe />
      <RankUpModal />
      <Toaster
        theme="dark"
        position="bottom-right"
        visibleToasts={2}
        toastOptions={{
          duration: 2800,
          className:
            "!bg-surface !text-fg !border-border font-sans !rounded-md",
        }}
      />
    </div>
  );
}

function Header() {
  const today = todayKey();
  return (
    <header className="stagger-in flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <p className="font-mono text-2xs uppercase tracking-hud text-accent">
          {routine.tagline}
        </p>
        <h1 className="mt-1 font-display text-4xl font-semibold tracking-tight text-fg sm:text-5xl">
          {routine.name}
        </h1>
      </div>
      <p className="font-mono text-xs uppercase tracking-widest text-muted">
        {formatLongDate(today)}
      </p>
    </header>
  );
}

function LoadedBoard() {
  const days = useHunterStore((s) => s.days);
  const today = ensureDay(days, todayKey());
  const cleared = routine.quests.filter((q) => today.quests[q.id]?.completed)
    .length;
  const allDone = dayFullyCleared(today);

  return (
    <>
      <PlayerWindow />
      <section>
        <div className="mb-3 flex items-end justify-between gap-3">
          <div>
            <p className="font-mono text-2xs uppercase tracking-hud text-accent">
              Daily quests
            </p>
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              {allDone ? "Gate cleared" : "Today's objectives"}
            </h2>
          </div>
          <p className="font-mono text-xs tabular-nums uppercase tracking-widest text-muted">
            {cleared} / {routine.quests.length} complete
          </p>
        </div>
        {allDone ? (
          <p className="mb-4 rounded-md bg-surface px-4 py-3 font-mono text-2xs uppercase tracking-widest text-accent shadow-hud-hover">
            Daily clear bonus claimed · +{routine.dailyClearBonus} XP
          </p>
        ) : null}
        <div className="grid gap-4 md:grid-cols-2">
          {routine.quests.map((quest, index) => (
            <QuestCard key={quest.id} quest={quest} index={index} />
          ))}
        </div>
      </section>
      <WeekLog />
      <StatsRow />
    </>
  );
}

function StatsRow() {
  const xp = useHunterStore((s) => s.xp);
  const days = useHunterStore((s) => s.days);
  const clearedDays = Object.values(days).filter((d) => d.bonusClaimed).length;
  const quests = Object.values(days).reduce((n, d) => {
    return n + Object.values(d.quests).filter((q) => q.completed).length;
  }, 0);

  return (
    <div className="stagger-in grid grid-cols-3 gap-2 sm:gap-4">
      <MiniStat label="Total XP" value={xp.toLocaleString()} />
      <MiniStat label="Days cleared" value={String(clearedDays)} />
      <MiniStat label="Quests done" value={String(quests)} />
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-surface px-3 py-3 shadow-hud sm:px-4">
      <p className="font-mono text-2xs uppercase tracking-widest text-faint">
        {label}
      </p>
      <p className="mt-1 font-display text-2xl font-semibold tabular-nums leading-none text-fg">
        {value}
      </p>
    </div>
  );
}

function BoardSkeleton() {
  return (
    <div className="flex flex-col gap-6" aria-hidden="true">
      <div className="h-40 rounded-lg bg-surface shadow-hud" />
      <div className="grid gap-4 md:grid-cols-2">
        <div className="h-52 rounded-lg bg-surface shadow-hud" />
        <div className="h-52 rounded-lg bg-surface shadow-hud" />
        <div className="h-52 rounded-lg bg-surface shadow-hud" />
        <div className="h-52 rounded-lg bg-surface shadow-hud" />
      </div>
      <div className="h-36 rounded-lg bg-surface shadow-hud" />
    </div>
  );
}
