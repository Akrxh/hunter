import { Download, RotateCcw, Upload } from "lucide-react";
import { useRef } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useHunterStore } from "@/lib/store";

export function DataTools() {
  const fileRef = useRef<HTMLInputElement>(null);
  const exportSave = useHunterStore((s) => s.exportSave);
  const importSave = useHunterStore((s) => s.importSave);
  const resetAll = useHunterStore((s) => s.resetAll);

  function onExport() {
    const blob = new Blob([exportSave()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "hunter-protocol.json";
    a.click();
    URL.revokeObjectURL(url);
    toast.message("Save exported as hunter-protocol.json");
  }

  function onImport(file: File | undefined) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const ok = importSave(String(reader.result ?? ""));
      toast[ok ? "success" : "error"](
        ok ? "Save imported" : "Could not read that JSON file",
      );
    };
    reader.readAsText(file);
  }

  function onReset() {
    const ok = window.confirm(
      "Reset hunter data? Levels, streaks, and daily logs will be wiped.",
    );
    if (!ok) return;
    resetAll();
    toast.message("Hunter log reset");
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Button type="button" variant="ghost" size="sm" onClick={onExport}>
        <Download className="size-3.5" />
        Export JSON
      </Button>
      <Button
        type="button"
        variant="ghost"
        size="sm"
        onClick={() => fileRef.current?.click()}
      >
        <Upload className="size-3.5" />
        Import JSON
      </Button>
      <Button type="button" variant="ghost" size="sm" onClick={onReset}>
        <RotateCcw className="size-3.5" />
        Reset
      </Button>
      <input
        ref={fileRef}
        type="file"
        accept="application/json,.json"
        className="sr-only"
        onChange={(e) => {
          onImport(e.target.files?.[0]);
          e.currentTarget.value = "";
        }}
      />
    </div>
  );
}
