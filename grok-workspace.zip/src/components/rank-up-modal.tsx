import { useEffect } from "react";
import { RankSeal } from "@/components/rank-seal";
import { Button } from "@/components/ui/button";
import { useHunterStore } from "@/lib/store";
import { progressFromXp, routine } from "@/lib/system";

export function RankUpModal() {
  const rankUp = useHunterStore((s) => s.rankUp);
  const dismiss = useHunterStore((s) => s.dismissRankUp);

  useEffect(() => {
    if (!rankUp) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape" || e.key === "Enter") dismiss();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [rankUp, dismiss]);

  if (!rankUp) return null;

  const from = routine.ranks.find((r) => r.id === rankUp.fromId);
  const to = routine.ranks.find((r) => r.id === rankUp.toId);
  const level = progressFromXp(useHunterStore.getState().xp).level;

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-bg/85 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="rank-up-title"
      onClick={dismiss}
    >
      <div
        className="hud-corners w-full max-w-md rounded-xl bg-surface p-6 text-center shadow-hud-hover sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <span className="hud-corner-bl" />
        <span className="hud-corner-br" />
        <p className="font-mono text-2xs uppercase tracking-hud text-accent">
          System notice
        </p>
        <h2
          id="rank-up-title"
          className="mt-2 font-display text-3xl font-semibold tracking-tight text-fg"
        >
          Rank increased
        </h2>
        <div className="mt-8 flex items-center justify-center gap-5">
          <RankSeal letter={from?.id ?? "?"} size="md" />
          <span className="font-display text-2xl text-accent">→</span>
          <RankSeal
            letter={to?.id ?? "?"}
            size="md"
            filled={to?.id === "M"}
          />
        </div>
        <p className="mt-6 font-display text-xl text-fg">
          {to?.name} · {to?.title}
        </p>
        <p className="mt-1 font-mono text-xs uppercase tracking-widest text-muted">
          Level {level.toString().padStart(2, "0")}
        </p>
        <Button type="button" className="mt-8 w-full" onClick={dismiss}>
          Confirm
        </Button>
      </div>
    </div>
  );
}
