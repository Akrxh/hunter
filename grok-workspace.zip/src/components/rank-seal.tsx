import { cn } from "@/lib/utils";

export function RankSeal({
  letter,
  filled = false,
  size = "md",
}: {
  letter: string;
  filled?: boolean;
  size?: "sm" | "md" | "lg";
}) {
  const dim = size === "lg" ? "size-28" : size === "sm" ? "size-12" : "size-20";
  const type =
    size === "lg" ? "text-5xl" : size === "sm" ? "text-lg" : "text-3xl";

  return (
    <div
      className={cn("relative grid place-items-center text-accent", dim)}
      aria-hidden="true"
    >
      <svg viewBox="0 0 80 80" className="absolute inset-0">
        <polygon
          points="40,3 75,22 75,58 40,77 5,58 5,22"
          fill={
            filled
              ? "currentColor"
              : "color-mix(in oklab, var(--color-accent) 12%, transparent)"
          }
          stroke="currentColor"
          strokeWidth="2.2"
        />
        <polygon
          points="40,12 67,27 67,53 40,68 13,53 13,27"
          fill="none"
          stroke="currentColor"
          strokeWidth="0.8"
          opacity="0.45"
        />
      </svg>
      <span
        className={cn(
          "relative font-display font-bold leading-none tracking-tight",
          type,
          filled ? "text-bg" : "text-fg",
        )}
      >
        {letter}
      </span>
    </div>
  );
}
