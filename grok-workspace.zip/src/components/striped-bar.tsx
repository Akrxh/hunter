import { cn } from "@/lib/utils";

export function StripedBar({
  value,
  className,
  done = false,
}: {
  value: number;
  className?: string;
  done?: boolean;
}) {
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div
      className={cn(
        "h-2 overflow-hidden rounded-xs bg-surface-2 shadow-[inset_0_0_0_1px_var(--color-border)]",
        className,
      )}
      role="progressbar"
      aria-valuenow={Math.round(pct)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className={cn(
          "h-full origin-left transition-[width] duration-300 ease-out",
          done ? "bg-ok" : "stripe-fill",
        )}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}
