import { cn } from "@/lib/utils";

export function HazardStripe({
  className,
  animated = false,
}: {
  className?: string;
  animated?: boolean;
}) {
  return (
    <div
      aria-hidden="true"
      className={cn(
        "stripe-tape h-2.5 w-full",
        animated && "stripe-shift",
        className,
      )}
    />
  );
}
