import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function HudFrame({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("hud-corners rounded-lg bg-surface p-4 shadow-hud sm:p-5", className)}>
      <span className="hud-corner-bl" />
      <span className="hud-corner-br" />
      {children}
    </div>
  );
}
