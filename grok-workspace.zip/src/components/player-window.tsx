import { Flame, Pencil } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { HudFrame } from "@/components/hud-frame";
import { RankSeal } from "@/components/rank-seal";
import { StripedBar } from "@/components/striped-bar";
import { useHunterStats, useHunterStore } from "@/lib/store";
import { nextRank } from "@/lib/system";

export function PlayerWindow() {
  const hunterName = useHunterStore((s) => s.hunterName);
  const setName = useHunterStore((s) => s.setName);
  const stats = useHunterStats();
  const upcoming = nextRank(stats.progress.level);
  const pct = (stats.progress.into / stats.progress.need) * 100;
  const [editing, setEditing] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editing) inputRef.current?.select();
  }, [editing]);

  return (
    <HudFrame className="stagger-in">
      <p className="mb-4 font-mono text-2xs font-medium uppercase tracking-hud text-accent">
        Player status window
      </p>
      <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:gap-6">
        <RankSeal letter={stats.rank.id} filled={stats.rank.id === "M"} />

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            {editing ? (
              <input
                ref={inputRef}
                defaultValue={hunterName}
                maxLength={24}
                aria-label="Hunter name"
                className="h-10 w-full max-w-xs rounded-sm bg-surface-2 px-2 font-display text-2xl font-semibold tracking-tight text-fg shadow-hud outline-none focus:shadow-hud-hover"
                onBlur={(e) => {
                  setName(e.target.value);
                  setEditing(false);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    setName(e.currentTarget.value);
                    setEditing(false);
                  }
                  if (e.key === "Escape") setEditing(false);
                }}
              />
            ) : (
              <button
                type="button"
                onClick={() => setEditing(true)}
                className="group flex min-h-11 max-w-full items-center gap-2 text-left"
              >
                <span className="truncate font-display text-2xl font-semibold tracking-tight text-fg sm:text-3xl">
                  {hunterName}
                </span>
                <Pencil className="size-3.5 shrink-0 text-faint transition-colors duration-150 group-hover:text-muted" />
              </button>
            )}
          </div>
          <p className="mt-1 font-mono text-xs uppercase tracking-widest text-muted">
            {stats.rank.name}
            <span className="mx-2 text-faint">/</span>
            {stats.rank.title}
          </p>
        </div>

        <div className="grid min-w-0 flex-[1.2] grid-cols-2 gap-4 sm:max-w-md">
          <div className="col-span-2">
            <div className="mb-1.5 flex items-baseline justify-between gap-3 font-mono text-2xs uppercase tracking-widest text-muted">
              <span>Lv.{stats.progress.level.toString().padStart(2, "0")}</span>
              <span className="tabular-nums text-fg">
                {stats.progress.into} / {stats.progress.need} XP
              </span>
            </div>
            <StripedBar value={pct} className="h-2.5" />
            <p className="mt-1.5 font-mono text-2xs uppercase tracking-widest text-faint">
              {upcoming
                ? `Next rank ${upcoming.name} at lv.${upcoming.minLevel}`
                : "Peak rank attained"}
            </p>
          </div>
          <Stat label="Streak" value={`${stats.streak}d`} icon />
          <Stat label="Best" value={`${stats.bestStreak}d`} />
        </div>
      </div>
    </HudFrame>
  );
}

function Stat({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon?: boolean;
}) {
  return (
    <div className="rounded-md bg-surface-2 px-3 py-2.5 shadow-hud">
      <p className="font-mono text-2xs uppercase tracking-widest text-faint">
        {label}
      </p>
      <p className="mt-0.5 flex items-center gap-1.5 font-display text-xl font-semibold tabular-nums leading-none text-fg">
        {icon ? <Flame className="size-4 text-accent" /> : null}
        {value}
      </p>
    </div>
  );
}
