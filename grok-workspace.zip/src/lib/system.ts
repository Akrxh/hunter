import routineData from "@/data/routine.json";

export type QuestIcon = "dumbbell" | "book" | "play" | "library";

export type QuestDef = {
  id: string;
  code: string;
  title: string;
  label: string;
  detail: string;
  durationMin: number;
  xp: number;
  icon: QuestIcon;
};

export type RankDef = {
  id: string;
  name: string;
  title: string;
  minLevel: number;
};

export type RoutineConfig = {
  name: string;
  tagline: string;
  dailyClearBonus: number;
  quests: QuestDef[];
  ranks: RankDef[];
};

export const routine = routineData as RoutineConfig;

export type QuestLog = {
  elapsedSec: number;
  runningStartedAt: number | null;
  completed: boolean;
};

export type DayLog = {
  quests: Record<string, QuestLog>;
  bonusClaimed: boolean;
};

export function todayKey(date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function parseKey(key: string): Date {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1);
}

export function addDays(key: string, delta: number): string {
  const date = parseKey(key);
  date.setDate(date.getDate() + delta);
  return todayKey(date);
}

export function diffDays(later: string, earlier: string): number {
  const a = parseKey(later).getTime();
  const b = parseKey(earlier).getTime();
  return Math.round((a - b) / 86_400_000);
}

export function emptyQuest(): QuestLog {
  return { elapsedSec: 0, runningStartedAt: null, completed: false };
}

export function emptyDay(): DayLog {
  const quests: Record<string, QuestLog> = {};
  for (const quest of routine.quests) {
    quests[quest.id] = emptyQuest();
  }
  return { quests, bonusClaimed: false };
}

export function ensureDay(days: Record<string, DayLog>, key: string): DayLog {
  const existing = days[key];
  if (!existing) return emptyDay();
  const quests = { ...existing.quests };
  for (const quest of routine.quests) {
    if (!quests[quest.id]) quests[quest.id] = emptyQuest();
  }
  return { ...existing, quests };
}

export function xpToNext(level: number): number {
  return 80 + (level - 1) * 25;
}

export function progressFromXp(xp: number): {
  level: number;
  into: number;
  need: number;
} {
  let remaining = Math.max(0, xp);
  let level = 1;
  for (;;) {
    const need = xpToNext(level);
    if (remaining < need) return { level, into: remaining, need };
    remaining -= need;
    level += 1;
    if (level > 999) return { level, into: 0, need: xpToNext(level) };
  }
}

export function rankForLevel(level: number): RankDef {
  const sorted = [...routine.ranks].sort((a, b) => a.minLevel - b.minLevel);
  let current = sorted[0];
  for (const rank of sorted) {
    if (level >= rank.minLevel) current = rank;
  }
  return current ?? sorted[0];
}

export function nextRank(level: number): RankDef | null {
  const sorted = [...routine.ranks].sort((a, b) => a.minLevel - b.minLevel);
  const current = rankForLevel(level);
  const idx = sorted.findIndex((r) => r.id === current.id);
  return sorted[idx + 1] ?? null;
}

export function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

export function formatClock(totalSec: number): string {
  const sec = Math.max(0, Math.floor(totalSec));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  if (h > 0) return `${h}:${pad2(m)}:${pad2(s)}`;
  return `${m}:${pad2(s)}`;
}

export function formatGoal(min: number): string {
  if (min % 60 === 0) {
    const h = min / 60;
    return h === 1 ? "1 hr" : `${h} hr`;
  }
  if (min > 60) {
    const h = Math.floor(min / 60);
    const m = min % 60;
    return `${h} hr ${m} min`;
  }
  return `${min} min`;
}

export function formatLongDate(key: string): string {
  return parseKey(key).toLocaleDateString(undefined, {
    weekday: "long",
    month: "short",
    day: "numeric",
  });
}

export function elapsedNow(log: QuestLog, now: number): number {
  const extra = log.runningStartedAt
    ? Math.max(0, Math.floor((now - log.runningStartedAt) / 1000))
    : 0;
  return log.elapsedSec + extra;
}

export function dayFullyCleared(day: DayLog): boolean {
  return routine.quests.every((q) => day.quests[q.id]?.completed);
}

export function countClearedQuests(days: Record<string, DayLog>): number {
  let n = 0;
  for (const day of Object.values(days)) {
    for (const quest of Object.values(day.quests)) {
      if (quest.completed) n += 1;
    }
  }
  return n;
}

export function countClearedDays(days: Record<string, DayLog>): number {
  return Object.values(days).filter((d) => d.bonusClaimed || dayFullyCleared(d))
    .length;
}

export function pauseRunning(day: DayLog, now: number): DayLog {
  const quests: Record<string, QuestLog> = {};
  for (const [id, log] of Object.entries(day.quests)) {
    if (log.runningStartedAt) {
      quests[id] = {
        ...log,
        elapsedSec: elapsedNow(log, now),
        runningStartedAt: null,
      };
    } else {
      quests[id] = log;
    }
  }
  return { ...day, quests };
}

export function pruneDays(
  days: Record<string, DayLog>,
  today: string,
  keep = 90,
): Record<string, DayLog> {
  const next: Record<string, DayLog> = {};
  for (const [key, value] of Object.entries(days)) {
    if (diffDays(today, key) <= keep) next[key] = value;
  }
  return next;
}

export function latestClearDate(
  days: Record<string, DayLog>,
  today: string,
): string | null {
  let best: string | null = null;
  for (const [key, day] of Object.entries(days)) {
    if (!(day.bonusClaimed || dayFullyCleared(day))) continue;
    if (key > today) continue;
    if (!best || key > best) best = key;
  }
  return best;
}

export function weekKeys(today: string): string[] {
  return Array.from({ length: 7 }, (_, i) => addDays(today, i - 6));
}
