import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  countClearedDays,
  countClearedQuests,
  dayFullyCleared,
  diffDays,
  emptyDay,
  emptyQuest,
  ensureDay,
  elapsedNow,
  latestClearDate,
  pauseRunning,
  progressFromXp,
  pruneDays,
  rankForLevel,
  routine,
  todayKey,
  type DayLog,
} from "@/lib/system";

export type RankUpEvent = {
  fromId: string;
  toId: string;
  level: number;
};

type HunterState = {
  hydrated: boolean;
  hunterName: string;
  xp: number;
  streak: number;
  bestStreak: number;
  lastClearDate: string | null;
  lastSeenDate: string | null;
  days: Record<string, DayLog>;
  rankUp: RankUpEvent | null;
  hydrate: () => void;
  setName: (name: string) => void;
  startQuest: (id: string) => void;
  pauseQuest: (id: string) => void;
  resetQuest: (id: string) => void;
  completeQuest: (id: string) => void;
  uncompleteQuest: (id: string) => void;
  dismissRankUp: () => void;
  exportSave: () => string;
  importSave: (raw: string) => boolean;
  resetAll: () => void;
};

type Persisted = Pick<
  HunterState,
  | "hunterName"
  | "xp"
  | "streak"
  | "bestStreak"
  | "lastClearDate"
  | "lastSeenDate"
  | "days"
>;

const DEFAULTS: Persisted = {
  hunterName: "Hunter-000",
  xp: 0,
  streak: 0,
  bestStreak: 0,
  lastClearDate: null,
  lastSeenDate: null,
  days: {},
};

function awardXp(
  xp: number,
  amount: number,
): { xp: number; rankUp: RankUpEvent | null } {
  const prev = rankForLevel(progressFromXp(xp).level);
  const nextXp = Math.max(0, xp + amount);
  const next = rankForLevel(progressFromXp(nextXp).level);
  const rankUp =
    next.minLevel > prev.minLevel
      ? { fromId: prev.id, toId: next.id, level: progressFromXp(nextXp).level }
      : null;
  return { xp: nextXp, rankUp };
}

function applyRollover(state: Persisted, now: number): Persisted {
  const today = todayKey();
  let days = { ...state.days };
  for (const key of Object.keys(days)) {
    const day = days[key];
    if (!day) continue;
    days[key] = pauseRunning(day, now);
  }
  days[today] = ensureDay(days, today);
  days = pruneDays(days, today);

  let streak = state.streak;
  let lastClearDate = state.lastClearDate;
  if (lastClearDate && diffDays(today, lastClearDate) > 1) {
    streak = 0;
  }
  if (!lastClearDate) streak = 0;

  return {
    ...state,
    days,
    streak,
    lastClearDate,
    lastSeenDate: today,
  };
}

function maybeClaimBonus(
  day: DayLog,
  xp: number,
  streak: number,
  bestStreak: number,
  lastClearDate: string | null,
  today: string,
): {
  day: DayLog;
  xp: number;
  streak: number;
  bestStreak: number;
  lastClearDate: string | null;
  rankUp: RankUpEvent | null;
} {
  if (day.bonusClaimed || !dayFullyCleared(day)) {
    return { day, xp, streak, bestStreak, lastClearDate, rankUp: null };
  }
  const awarded = awardXp(xp, routine.dailyClearBonus);
  const nextStreak = streak + 1;
  return {
    day: { ...day, bonusClaimed: true },
    xp: awarded.xp,
    streak: nextStreak,
    bestStreak: Math.max(bestStreak, nextStreak),
    lastClearDate: today,
    rankUp: awarded.rankUp,
  };
}

export const useHunterStore = create<HunterState>()(
  persist(
    (set, get) => ({
      ...DEFAULTS,
      hydrated: false,
      rankUp: null,

      hydrate: () => {
        const rolled = applyRollover(
          {
            hunterName: get().hunterName,
            xp: get().xp,
            streak: get().streak,
            bestStreak: get().bestStreak,
            lastClearDate: get().lastClearDate,
            lastSeenDate: get().lastSeenDate,
            days: get().days,
          },
          Date.now(),
        );
        set({ ...rolled, hydrated: true });
      },

      setName: (name) => {
        const trimmed = name.trim().slice(0, 24) || "Hunter-000";
        set({ hunterName: trimmed });
      },

      startQuest: (id) => {
        const today = todayKey();
        const now = Date.now();
        const days = { ...get().days };
        let day = pauseRunning(ensureDay(days, today), now);
        const log = day.quests[id] ?? emptyQuest();
        if (log.completed) return;
        day = {
          ...day,
          quests: {
            ...day.quests,
            [id]: { ...log, runningStartedAt: now },
          },
        };
        days[today] = day;
        set({ days });
      },

      pauseQuest: (id) => {
        const today = todayKey();
        const now = Date.now();
        const days = { ...get().days };
        const day = ensureDay(days, today);
        const log = day.quests[id] ?? emptyQuest();
        days[today] = {
          ...day,
          quests: {
            ...day.quests,
            [id]: {
              ...log,
              elapsedSec: elapsedNow(log, now),
              runningStartedAt: null,
            },
          },
        };
        set({ days });
      },

      resetQuest: (id) => {
        const today = todayKey();
        const days = { ...get().days };
        const day = ensureDay(days, today);
        const log = day.quests[id] ?? emptyQuest();
        if (log.completed) return;
        days[today] = {
          ...day,
          quests: {
            ...day.quests,
            [id]: emptyQuest(),
          },
        };
        set({ days });
      },

      completeQuest: (id) => {
        const today = todayKey();
        const now = Date.now();
        const quest = routine.quests.find((q) => q.id === id);
        if (!quest) return;
        const state = get();
        const days = { ...state.days };
        let day = pauseRunning(ensureDay(days, today), now);
        const log = day.quests[id] ?? emptyQuest();
        if (log.completed) return;

        day = {
          ...day,
          quests: {
            ...day.quests,
            [id]: {
              elapsedSec: Math.max(log.elapsedSec, quest.durationMin * 60),
              runningStartedAt: null,
              completed: true,
            },
          },
        };

        let awarded = awardXp(state.xp, quest.xp);
        const bonus = maybeClaimBonus(
          day,
          awarded.xp,
          state.streak,
          state.bestStreak,
          state.lastClearDate,
          today,
        );
        days[today] = bonus.day;
        set({
          days,
          xp: bonus.xp,
          streak: bonus.streak,
          bestStreak: bonus.bestStreak,
          lastClearDate: bonus.lastClearDate,
          rankUp: bonus.rankUp ?? awarded.rankUp ?? state.rankUp,
        });
      },

      uncompleteQuest: (id) => {
        const today = todayKey();
        const quest = routine.quests.find((q) => q.id === id);
        if (!quest) return;
        const state = get();
        const days = { ...state.days };
        const day = ensureDay(days, today);
        const log = day.quests[id] ?? emptyQuest();
        if (!log.completed) return;

        let xp = state.xp;
        let rankUp = state.rankUp;
        const refundQuest = awardXp(xp, -quest.xp);
        xp = refundQuest.xp;
        if (refundQuest.rankUp) rankUp = refundQuest.rankUp;

        let streak = state.streak;
        let lastClearDate = state.lastClearDate;
        let bonusClaimed = day.bonusClaimed;
        if (day.bonusClaimed) {
          const refundBonus = awardXp(xp, -routine.dailyClearBonus);
          xp = refundBonus.xp;
          if (refundBonus.rankUp) rankUp = refundBonus.rankUp;
          bonusClaimed = false;
          streak = Math.max(0, streak - 1);
          const nextDays = {
            ...days,
            [today]: {
              ...day,
              bonusClaimed: false,
              quests: {
                ...day.quests,
                [id]: emptyQuest(),
              },
            },
          };
          lastClearDate = latestClearDate(nextDays, today);
        }

        days[today] = {
          ...day,
          bonusClaimed,
          quests: {
            ...day.quests,
            [id]: emptyQuest(),
          },
        };
        set({ days, xp, streak, lastClearDate, rankUp });
      },

      dismissRankUp: () => set({ rankUp: null }),

      exportSave: () => {
        const s = get();
        return JSON.stringify(
          {
            hunterName: s.hunterName,
            xp: s.xp,
            streak: s.streak,
            bestStreak: s.bestStreak,
            lastClearDate: s.lastClearDate,
            lastSeenDate: s.lastSeenDate,
            days: s.days,
          },
          null,
          2,
        );
      },

      importSave: (raw) => {
        try {
          const parsed = JSON.parse(raw) as Partial<Persisted>;
          if (typeof parsed.xp !== "number" || !parsed.days) return false;
          const rolled = applyRollover(
            {
              hunterName:
                typeof parsed.hunterName === "string"
                  ? parsed.hunterName
                  : "Hunter-000",
              xp: parsed.xp,
              streak: typeof parsed.streak === "number" ? parsed.streak : 0,
              bestStreak:
                typeof parsed.bestStreak === "number" ? parsed.bestStreak : 0,
              lastClearDate: parsed.lastClearDate ?? null,
              lastSeenDate: parsed.lastSeenDate ?? null,
              days: parsed.days,
            },
            Date.now(),
          );
          set({ ...rolled, rankUp: null });
          return true;
        } catch {
          return false;
        }
      },

      resetAll: () => {
        set({ ...DEFAULTS, hydrated: true, rankUp: null, days: {} });
      },
    }),
    {
      name: "hunter-protocol-v1",
      skipHydration: true,
      partialize: (s): Persisted => ({
        hunterName: s.hunterName,
        xp: s.xp,
        streak: s.streak,
        bestStreak: s.bestStreak,
        lastClearDate: s.lastClearDate,
        lastSeenDate: s.lastSeenDate,
        days: s.days,
      }),
    },
  ),
);

export function useHunterStats() {
  const xp = useHunterStore((s) => s.xp);
  const streak = useHunterStore((s) => s.streak);
  const bestStreak = useHunterStore((s) => s.bestStreak);
  const days = useHunterStore((s) => s.days);
  const progress = progressFromXp(xp);
  const rank = rankForLevel(progress.level);
  return {
    xp,
    streak,
    bestStreak,
    progress,
    rank,
    clearedQuests: countClearedQuests(days),
    clearedDays: countClearedDays(days),
  };
}
