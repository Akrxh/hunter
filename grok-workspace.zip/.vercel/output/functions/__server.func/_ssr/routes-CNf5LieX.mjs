import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Pencil, c as Dumbbell, d as BookOpen, f as BookMarked, i as Play, l as Download, o as Pause, r as RotateCcw, s as Flame, t as Upload, u as Check } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CNf5LieX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-display text-sm font-semibold tracking-wide uppercase transition-[background-color,color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-accent)_70%,black)] hover:bg-accent-dim",
			outline: "bg-transparent text-fg shadow-[0_0_0_1px_var(--color-border)] hover:shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-accent)_55%,var(--color-border))] hover:text-accent-fg",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-surface-2",
			success: "bg-ok text-accent-fg hover:opacity-90"
		},
		size: {
			default: "h-11 rounded-sm px-4",
			sm: "h-9 rounded-sm px-3 text-xs",
			icon: "size-11 rounded-sm",
			"icon-sm": "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var routine = {
	name: "Hunter Protocol",
	tagline: "Daily Quest Board",
	dailyClearBonus: 120,
	quests: [
		{
			"id": "exercise",
			"code": "Q-01",
			"title": "Physical Training",
			"label": "Exercise",
			"detail": "Train the body. Complete 45 minutes of exercise.",
			"durationMin": 45,
			"xp": 120,
			"icon": "dumbbell"
		},
		{
			"id": "study",
			"code": "Q-02",
			"title": "Knowledge Gate",
			"label": "Study",
			"detail": "Hold the line. Study for 6 hours.",
			"durationMin": 360,
			"xp": 250,
			"icon": "book"
		},
		{
			"id": "anime",
			"code": "Q-03",
			"title": "Recovery Protocol",
			"label": "Anime",
			"detail": "Restore the mind. Watch 2 hours of anime.",
			"durationMin": 120,
			"xp": 70,
			"icon": "play"
		},
		{
			"id": "reading",
			"code": "Q-04",
			"title": "Archive Dive",
			"label": "Reading",
			"detail": "Read for 1 hour. No skimming.",
			"durationMin": 60,
			"xp": 90,
			"icon": "library"
		}
	],
	ranks: [
		{
			"id": "E",
			"name": "E-Rank",
			"title": "Novice Hunter",
			"minLevel": 1
		},
		{
			"id": "D",
			"name": "D-Rank",
			"title": "Ranked Hunter",
			"minLevel": 5
		},
		{
			"id": "C",
			"name": "C-Rank",
			"title": "Veteran Hunter",
			"minLevel": 12
		},
		{
			"id": "B",
			"name": "B-Rank",
			"title": "Elite Hunter",
			"minLevel": 20
		},
		{
			"id": "A",
			"name": "A-Rank",
			"title": "High-Rank Hunter",
			"minLevel": 32
		},
		{
			"id": "S",
			"name": "S-Rank",
			"title": "S-Class Hunter",
			"minLevel": 48
		},
		{
			"id": "N",
			"name": "National",
			"title": "National-Level Hunter",
			"minLevel": 70
		},
		{
			"id": "M",
			"name": "Monarch",
			"title": "Monarch-Class Hunter",
			"minLevel": 100
		}
	]
};
function todayKey(date = /* @__PURE__ */ new Date()) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function parseKey(key) {
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y, (m ?? 1) - 1, d ?? 1);
}
function addDays(key, delta) {
	const date = parseKey(key);
	date.setDate(date.getDate() + delta);
	return todayKey(date);
}
function diffDays(later, earlier) {
	const a = parseKey(later).getTime();
	const b = parseKey(earlier).getTime();
	return Math.round((a - b) / 864e5);
}
function emptyQuest() {
	return {
		elapsedSec: 0,
		runningStartedAt: null,
		completed: false
	};
}
function emptyDay() {
	const quests = {};
	for (const quest of routine.quests) quests[quest.id] = emptyQuest();
	return {
		quests,
		bonusClaimed: false
	};
}
function ensureDay(days, key) {
	const existing = days[key];
	if (!existing) return emptyDay();
	const quests = { ...existing.quests };
	for (const quest of routine.quests) if (!quests[quest.id]) quests[quest.id] = emptyQuest();
	return {
		...existing,
		quests
	};
}
function xpToNext(level) {
	return 80 + (level - 1) * 25;
}
function progressFromXp(xp) {
	let remaining = Math.max(0, xp);
	let level = 1;
	for (;;) {
		const need = xpToNext(level);
		if (remaining < need) return {
			level,
			into: remaining,
			need
		};
		remaining -= need;
		level += 1;
		if (level > 999) return {
			level,
			into: 0,
			need: xpToNext(level)
		};
	}
}
function rankForLevel(level) {
	const sorted = [...routine.ranks].sort((a, b) => a.minLevel - b.minLevel);
	let current = sorted[0];
	for (const rank of sorted) if (level >= rank.minLevel) current = rank;
	return current ?? sorted[0];
}
function nextRank(level) {
	const sorted = [...routine.ranks].sort((a, b) => a.minLevel - b.minLevel);
	const current = rankForLevel(level);
	return sorted[sorted.findIndex((r) => r.id === current.id) + 1] ?? null;
}
function pad2(n) {
	return String(n).padStart(2, "0");
}
function formatClock(totalSec) {
	const sec = Math.max(0, Math.floor(totalSec));
	const h = Math.floor(sec / 3600);
	const m = Math.floor(sec % 3600 / 60);
	const s = sec % 60;
	if (h > 0) return `${h}:${pad2(m)}:${pad2(s)}`;
	return `${m}:${pad2(s)}`;
}
function formatGoal(min) {
	if (min % 60 === 0) {
		const h = min / 60;
		return h === 1 ? "1 hr" : `${h} hr`;
	}
	if (min > 60) return `${Math.floor(min / 60)} hr ${min % 60} min`;
	return `${min} min`;
}
function formatLongDate(key) {
	return parseKey(key).toLocaleDateString(void 0, {
		weekday: "long",
		month: "short",
		day: "numeric"
	});
}
function elapsedNow(log, now) {
	const extra = log.runningStartedAt ? Math.max(0, Math.floor((now - log.runningStartedAt) / 1e3)) : 0;
	return log.elapsedSec + extra;
}
function dayFullyCleared(day) {
	return routine.quests.every((q) => day.quests[q.id]?.completed);
}
function countClearedQuests(days) {
	let n = 0;
	for (const day of Object.values(days)) for (const quest of Object.values(day.quests)) if (quest.completed) n += 1;
	return n;
}
function countClearedDays(days) {
	return Object.values(days).filter((d) => d.bonusClaimed || dayFullyCleared(d)).length;
}
function pauseRunning(day, now) {
	const quests = {};
	for (const [id, log] of Object.entries(day.quests)) if (log.runningStartedAt) quests[id] = {
		...log,
		elapsedSec: elapsedNow(log, now),
		runningStartedAt: null
	};
	else quests[id] = log;
	return {
		...day,
		quests
	};
}
function pruneDays(days, today, keep = 90) {
	const next = {};
	for (const [key, value] of Object.entries(days)) if (diffDays(today, key) <= keep) next[key] = value;
	return next;
}
function latestClearDate(days, today) {
	let best = null;
	for (const [key, day] of Object.entries(days)) {
		if (!(day.bonusClaimed || dayFullyCleared(day))) continue;
		if (key > today) continue;
		if (!best || key > best) best = key;
	}
	return best;
}
function weekKeys(today) {
	return Array.from({ length: 7 }, (_, i) => addDays(today, i - 6));
}
var DEFAULTS = {
	hunterName: "Hunter-000",
	xp: 0,
	streak: 0,
	bestStreak: 0,
	lastClearDate: null,
	lastSeenDate: null,
	days: {}
};
function awardXp(xp, amount) {
	const prev = rankForLevel(progressFromXp(xp).level);
	const nextXp = Math.max(0, xp + amount);
	const next = rankForLevel(progressFromXp(nextXp).level);
	return {
		xp: nextXp,
		rankUp: next.minLevel > prev.minLevel ? {
			fromId: prev.id,
			toId: next.id,
			level: progressFromXp(nextXp).level
		} : null
	};
}
function applyRollover(state, now) {
	const today = todayKey();
	let days = { ...state.days };
	for (const key of Object.keys(days)) {
		const day = days[key];
		if (!day) continue;
		days[key] = pauseRunning(day, now);
	}
	days[today] = ensureDay(days, today);
	days = pruneDays(days, today);
	let streak = state.streak;
	let lastClearDate = state.lastClearDate;
	if (lastClearDate && diffDays(today, lastClearDate) > 1) streak = 0;
	if (!lastClearDate) streak = 0;
	return {
		...state,
		days,
		streak,
		lastClearDate,
		lastSeenDate: today
	};
}
function maybeClaimBonus(day, xp, streak, bestStreak, lastClearDate, today) {
	if (day.bonusClaimed || !dayFullyCleared(day)) return {
		day,
		xp,
		streak,
		bestStreak,
		lastClearDate,
		rankUp: null
	};
	const awarded = awardXp(xp, routine.dailyClearBonus);
	const nextStreak = streak + 1;
	return {
		day: {
			...day,
			bonusClaimed: true
		},
		xp: awarded.xp,
		streak: nextStreak,
		bestStreak: Math.max(bestStreak, nextStreak),
		lastClearDate: today,
		rankUp: awarded.rankUp
	};
}
var useHunterStore = create()(persist((set, get) => ({
	...DEFAULTS,
	hydrated: false,
	rankUp: null,
	hydrate: () => {
		set({
			...applyRollover({
				hunterName: get().hunterName,
				xp: get().xp,
				streak: get().streak,
				bestStreak: get().bestStreak,
				lastClearDate: get().lastClearDate,
				lastSeenDate: get().lastSeenDate,
				days: get().days
			}, Date.now()),
			hydrated: true
		});
	},
	setName: (name) => {
		set({ hunterName: name.trim().slice(0, 24) || "Hunter-000" });
	},
	startQuest: (id) => {
		const today = todayKey();
		const now = Date.now();
		const days = { ...get().days };
		let day = pauseRunning(ensureDay(days, today), now);
		const log = day.quests[id] ?? emptyQuest();
		if (log.completed) return;
		day = {
			...day,
			quests: {
				...day.quests,
				[id]: {
					...log,
					runningStartedAt: now
				}
			}
		};
		days[today] = day;
		set({ days });
	},
	pauseQuest: (id) => {
		const today = todayKey();
		const now = Date.now();
		const days = { ...get().days };
		const day = ensureDay(days, today);
		const log = day.quests[id] ?? emptyQuest();
		days[today] = {
			...day,
			quests: {
				...day.quests,
				[id]: {
					...log,
					elapsedSec: elapsedNow(log, now),
					runningStartedAt: null
				}
			}
		};
		set({ days });
	},
	resetQuest: (id) => {
		const today = todayKey();
		const days = { ...get().days };
		const day = ensureDay(days, today);
		if ((day.quests[id] ?? emptyQuest()).completed) return;
		days[today] = {
			...day,
			quests: {
				...day.quests,
				[id]: emptyQuest()
			}
		};
		set({ days });
	},
	completeQuest: (id) => {
		const today = todayKey();
		const now = Date.now();
		const quest = routine.quests.find((q) => q.id === id);
		if (!quest) return;
		const state = get();
		const days = { ...state.days };
		let day = pauseRunning(ensureDay(days, today), now);
		const log = day.quests[id] ?? emptyQuest();
		if (log.completed) return;
		day = {
			...day,
			quests: {
				...day.quests,
				[id]: {
					elapsedSec: Math.max(log.elapsedSec, quest.durationMin * 60),
					runningStartedAt: null,
					completed: true
				}
			}
		};
		let awarded = awardXp(state.xp, quest.xp);
		const bonus = maybeClaimBonus(day, awarded.xp, state.streak, state.bestStreak, state.lastClearDate, today);
		days[today] = bonus.day;
		set({
			days,
			xp: bonus.xp,
			streak: bonus.streak,
			bestStreak: bonus.bestStreak,
			lastClearDate: bonus.lastClearDate,
			rankUp: bonus.rankUp ?? awarded.rankUp ?? state.rankUp
		});
	},
	uncompleteQuest: (id) => {
		const today = todayKey();
		const quest = routine.quests.find((q) => q.id === id);
		if (!quest) return;
		const state = get();
		const days = { ...state.days };
		const day = ensureDay(days, today);
		if (!(day.quests[id] ?? emptyQuest()).completed) return;
		let xp = state.xp;
		let rankUp = state.rankUp;
		const refundQuest = awardXp(xp, -quest.xp);
		xp = refundQuest.xp;
		if (refundQuest.rankUp) rankUp = refundQuest.rankUp;
		let streak = state.streak;
		let lastClearDate = state.lastClearDate;
		let bonusClaimed = day.bonusClaimed;
		if (day.bonusClaimed) {
			const refundBonus = awardXp(xp, -routine.dailyClearBonus);
			xp = refundBonus.xp;
			if (refundBonus.rankUp) rankUp = refundBonus.rankUp;
			bonusClaimed = false;
			streak = Math.max(0, streak - 1);
			lastClearDate = latestClearDate({
				...days,
				[today]: {
					...day,
					bonusClaimed: false,
					quests: {
						...day.quests,
						[id]: emptyQuest()
					}
				}
			}, today);
		}
		days[today] = {
			...day,
			bonusClaimed,
			quests: {
				...day.quests,
				[id]: emptyQuest()
			}
		};
		set({
			days,
			xp,
			streak,
			lastClearDate,
			rankUp
		});
	},
	dismissRankUp: () => set({ rankUp: null }),
	exportSave: () => {
		const s = get();
		return JSON.stringify({
			hunterName: s.hunterName,
			xp: s.xp,
			streak: s.streak,
			bestStreak: s.bestStreak,
			lastClearDate: s.lastClearDate,
			lastSeenDate: s.lastSeenDate,
			days: s.days
		}, null, 2);
	},
	importSave: (raw) => {
		try {
			const parsed = JSON.parse(raw);
			if (typeof parsed.xp !== "number" || !parsed.days) return false;
			set({
				...applyRollover({
					hunterName: typeof parsed.hunterName === "string" ? parsed.hunterName : "Hunter-000",
					xp: parsed.xp,
					streak: typeof parsed.streak === "number" ? parsed.streak : 0,
					bestStreak: typeof parsed.bestStreak === "number" ? parsed.bestStreak : 0,
					lastClearDate: parsed.lastClearDate ?? null,
					lastSeenDate: parsed.lastSeenDate ?? null,
					days: parsed.days
				}, Date.now()),
				rankUp: null
			});
			return true;
		} catch {
			return false;
		}
	},
	resetAll: () => {
		set({
			...DEFAULTS,
			hydrated: true,
			rankUp: null,
			days: {}
		});
	}
}), {
	name: "hunter-protocol-v1",
	skipHydration: true,
	partialize: (s) => ({
		hunterName: s.hunterName,
		xp: s.xp,
		streak: s.streak,
		bestStreak: s.bestStreak,
		lastClearDate: s.lastClearDate,
		lastSeenDate: s.lastSeenDate,
		days: s.days
	})
}));
function useHunterStats() {
	const xp = useHunterStore((s) => s.xp);
	const streak = useHunterStore((s) => s.streak);
	const bestStreak = useHunterStore((s) => s.bestStreak);
	const days = useHunterStore((s) => s.days);
	const progress = progressFromXp(xp);
	return {
		xp,
		streak,
		bestStreak,
		progress,
		rank: rankForLevel(progress.level),
		clearedQuests: countClearedQuests(days),
		clearedDays: countClearedDays(days)
	};
}
function DataTools() {
	const fileRef = (0, import_react.useRef)(null);
	const exportSave = useHunterStore((s) => s.exportSave);
	const importSave = useHunterStore((s) => s.importSave);
	const resetAll = useHunterStore((s) => s.resetAll);
	function onExport() {
		const blob = new Blob([exportSave()], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "hunter-protocol.json";
		a.click();
		URL.revokeObjectURL(url);
		toast.message("Save exported as hunter-protocol.json");
	}
	function onImport(file) {
		if (!file) return;
		const reader = new FileReader();
		reader.onload = () => {
			const ok = importSave(String(reader.result ?? ""));
			toast[ok ? "success" : "error"](ok ? "Save imported" : "Could not read that JSON file");
		};
		reader.readAsText(file);
	}
	function onReset() {
		if (!window.confirm("Reset hunter data? Levels, streaks, and daily logs will be wiped.")) return;
		resetAll();
		toast.message("Hunter log reset");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "ghost",
				size: "sm",
				onClick: onExport,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), "Export JSON"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "ghost",
				size: "sm",
				onClick: () => fileRef.current?.click(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3.5" }), "Import JSON"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "ghost",
				size: "sm",
				onClick: onReset,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), "Reset"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileRef,
				type: "file",
				accept: "application/json,.json",
				className: "sr-only",
				onChange: (e) => {
					onImport(e.target.files?.[0]);
					e.currentTarget.value = "";
				}
			})
		]
	});
}
function HazardStripe({ className, animated = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"aria-hidden": "true",
		className: cn("stripe-tape h-2.5 w-full", animated && "stripe-shift", className)
	});
}
function HudFrame({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("hud-corners rounded-lg bg-surface p-4 shadow-hud sm:p-5", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner-bl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner-br" }),
			children
		]
	});
}
function RankSeal({ letter, filled = false, size = "md" }) {
	const dim = size === "lg" ? "size-28" : size === "sm" ? "size-12" : "size-20";
	const type = size === "lg" ? "text-5xl" : size === "sm" ? "text-lg" : "text-3xl";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative grid place-items-center text-accent", dim),
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 80 80",
			className: "absolute inset-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "40,3 75,22 75,58 40,77 5,58 5,22",
				fill: filled ? "currentColor" : "color-mix(in oklab, var(--color-accent) 12%, transparent)",
				stroke: "currentColor",
				strokeWidth: "2.2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "40,12 67,27 67,53 40,68 13,53 13,27",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "0.8",
				opacity: "0.45"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("relative font-display font-bold leading-none tracking-tight", type, filled ? "text-bg" : "text-fg"),
			children: letter
		})]
	});
}
function StripedBar({ value, className, done = false }) {
	const pct = Math.max(0, Math.min(100, value));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("h-2 overflow-hidden rounded-xs bg-surface-2 shadow-[inset_0_0_0_1px_var(--color-border)]", className),
		role: "progressbar",
		"aria-valuenow": Math.round(pct),
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("h-full origin-left transition-[width] duration-300 ease-out", done ? "bg-ok" : "stripe-fill"),
			style: { width: `${pct}%` }
		})
	});
}
function PlayerWindow() {
	const hunterName = useHunterStore((s) => s.hunterName);
	const setName = useHunterStore((s) => s.setName);
	const stats = useHunterStats();
	const upcoming = nextRank(stats.progress.level);
	const pct = stats.progress.into / stats.progress.need * 100;
	const [editing, setEditing] = (0, import_react.useState)(false);
	const inputRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (editing) inputRef.current?.select();
	}, [editing]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HudFrame, {
		className: "stagger-in",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 font-mono text-2xs font-medium uppercase tracking-hud text-accent",
			children: "Player status window"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-5 sm:flex-row sm:items-center sm:gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankSeal, {
					letter: stats.rank.id,
					filled: stats.rank.id === "M"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-2",
						children: editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: inputRef,
							defaultValue: hunterName,
							maxLength: 24,
							"aria-label": "Hunter name",
							className: "h-10 w-full max-w-xs rounded-sm bg-surface-2 px-2 font-display text-2xl font-semibold tracking-tight text-fg shadow-hud outline-none focus:shadow-hud-hover",
							onBlur: (e) => {
								setName(e.target.value);
								setEditing(false);
							},
							onKeyDown: (e) => {
								if (e.key === "Enter") {
									setName(e.currentTarget.value);
									setEditing(false);
								}
								if (e.key === "Escape") setEditing(false);
							}
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setEditing(true),
							className: "group flex min-h-11 max-w-full items-center gap-2 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate font-display text-2xl font-semibold tracking-tight text-fg sm:text-3xl",
								children: hunterName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5 shrink-0 text-faint transition-colors duration-150 group-hover:text-muted" })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-mono text-xs uppercase tracking-widest text-muted",
						children: [
							stats.rank.name,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-2 text-faint",
								children: "/"
							}),
							stats.rank.title
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid min-w-0 flex-[1.2] grid-cols-2 gap-4 sm:max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "col-span-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-1.5 flex items-baseline justify-between gap-3 font-mono text-2xs uppercase tracking-widest text-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Lv.", stats.progress.level.toString().padStart(2, "0")] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "tabular-nums text-fg",
										children: [
											stats.progress.into,
											" / ",
											stats.progress.need,
											" XP"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StripedBar, {
									value: pct,
									className: "h-2.5"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1.5 font-mono text-2xs uppercase tracking-widest text-faint",
									children: upcoming ? `Next rank ${upcoming.name} at lv.${upcoming.minLevel}` : "Peak rank attained"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Streak",
							value: `${stats.streak}d`,
							icon: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Best",
							value: `${stats.bestStreak}d`
						})
					]
				})
			]
		})]
	});
}
function Stat({ label, value, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-surface-2 px-3 py-2.5 shadow-hud",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-2xs uppercase tracking-widest text-faint",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-0.5 flex items-center gap-1.5 font-display text-xl font-semibold tabular-nums leading-none text-fg",
			children: [icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-4 text-accent" }) : null, value]
		})]
	});
}
var ICONS = {
	dumbbell: Dumbbell,
	book: BookOpen,
	play: Play,
	library: BookMarked
};
function QuestCard({ quest, index }) {
	const today = todayKey();
	const days = useHunterStore((s) => s.days);
	const startQuest = useHunterStore((s) => s.startQuest);
	const pauseQuest = useHunterStore((s) => s.pauseQuest);
	const resetQuest = useHunterStore((s) => s.resetQuest);
	const completeQuest = useHunterStore((s) => s.completeQuest);
	const uncompleteQuest = useHunterStore((s) => s.uncompleteQuest);
	const log = ensureDay(days, today).quests[quest.id] ?? emptyQuest();
	const running = Boolean(log.runningStartedAt);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		if (!running) return;
		const id = window.setInterval(() => setNow(Date.now()), 250);
		return () => window.clearInterval(id);
	}, [running]);
	const elapsed = elapsedNow(log, now);
	const target = quest.durationMin * 60;
	const pct = log.completed ? 100 : Math.min(100, elapsed / target * 100);
	const Icon = ICONS[quest.icon];
	(0, import_react.useEffect)(() => {
		if (!running || log.completed) return;
		if (elapsed >= target) {
			completeQuest(quest.id);
			announce(quest);
		}
	}, [
		elapsed,
		running,
		log.completed,
		target,
		completeQuest,
		quest
	]);
	function onComplete() {
		if (log.completed) {
			uncompleteQuest(quest.id);
			return;
		}
		completeQuest(quest.id);
		announce(quest);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HudFrame, {
		className: cn("stagger-in flex h-full flex-col", log.completed && "bg-surface-2"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-11 shrink-0 place-items-center rounded-sm bg-surface-2 text-accent shadow-hud",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						strokeWidth: 1.75
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-2xs uppercase tracking-hud text-accent",
						children: [
							quest.code,
							" · ",
							formatGoal(quest.durationMin)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-xl font-semibold leading-tight tracking-tight text-fg",
						children: quest.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-sm text-muted",
						children: quest.detail
					})
				] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "shrink-0 font-mono text-xs tabular-nums text-muted",
				children: [
					"+",
					quest.xp,
					" XP"
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1.5 flex items-baseline justify-between font-mono text-2xs uppercase tracking-widest text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: log.completed ? "Cleared" : `Quest 0${index + 1}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-fg",
						children: [
							formatClock(Math.min(elapsed, target)),
							" / ",
							formatClock(target)
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StripedBar, {
					value: pct,
					done: log.completed,
					className: "h-2.5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: log.completed ? "outline" : "default",
							onClick: onComplete,
							className: cn("min-w-28 flex-1", log.completed && "text-ok"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), log.completed ? "Cleared" : "Complete"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => running ? pauseQuest(quest.id) : startQuest(quest.id),
							disabled: log.completed,
							className: "min-w-24",
							children: running ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }), " Pause"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), " Start"] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							onClick: () => resetQuest(quest.id),
							disabled: log.completed || elapsed === 0 && !running,
							"aria-label": "Reset timer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
						})
					]
				})
			]
		})]
	});
}
function announce(quest) {
	if (ensureDay(useHunterStore.getState().days, todayKey()).bonusClaimed) {
		toast.success(`Daily quests cleared · +${quest.xp + routine.dailyClearBonus} XP`);
		return;
	}
	toast.success(`${quest.label} cleared · +${quest.xp} XP`);
}
function RankUpModal() {
	const rankUp = useHunterStore((s) => s.rankUp);
	const dismiss = useHunterStore((s) => s.dismissRankUp);
	(0, import_react.useEffect)(() => {
		if (!rankUp) return;
		function onKey(e) {
			if (e.key === "Escape" || e.key === "Enter") dismiss();
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [rankUp, dismiss]);
	if (!rankUp) return null;
	const from = routine.ranks.find((r) => r.id === rankUp.fromId);
	const to = routine.ranks.find((r) => r.id === rankUp.toId);
	const level = progressFromXp(useHunterStore.getState().xp).level;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 grid place-items-center bg-bg/85 p-4",
		role: "dialog",
		"aria-modal": "true",
		"aria-labelledby": "rank-up-title",
		onClick: dismiss,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hud-corners w-full max-w-md rounded-xl bg-surface p-6 text-center shadow-hud-hover sm:p-8",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner-bl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner-br" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs uppercase tracking-hud text-accent",
					children: "System notice"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "rank-up-title",
					className: "mt-2 font-display text-3xl font-semibold tracking-tight text-fg",
					children: "Rank increased"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex items-center justify-center gap-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankSeal, {
							letter: from?.id ?? "?",
							size: "md"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-2xl text-accent",
							children: "→"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankSeal, {
							letter: to?.id ?? "?",
							size: "md",
							filled: to?.id === "M"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 font-display text-xl text-fg",
					children: [
						to?.name,
						" · ",
						to?.title
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 font-mono text-xs uppercase tracking-widest text-muted",
					children: ["Level ", level.toString().padStart(2, "0")]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					className: "mt-8 w-full",
					onClick: dismiss,
					children: "Confirm"
				})
			]
		})
	});
}
function WeekLog() {
	const days = useHunterStore((s) => s.days);
	const today = todayKey();
	const keys = weekKeys(today);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HudFrame, {
		className: "stagger-in",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-2xs uppercase tracking-hud text-accent",
				children: "Seven-day log"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold tracking-tight",
				children: "Recent gates"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-mono text-2xs uppercase tracking-widest text-faint",
				children: [routine.quests.length, " quests / day"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-7 gap-1.5 sm:gap-2",
			children: keys.map((key) => {
				const day = ensureDay(days, key);
				const done = routine.quests.filter((q) => day.quests[q.id]?.completed).length;
				const isToday = key === today;
				const label = parseKey(key).toLocaleDateString(void 0, { weekday: "short" });
				const date = parseKey(key).getDate();
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("flex flex-col items-center gap-2 rounded-md px-1 py-2.5 sm:px-2", isToday ? "bg-surface-2 shadow-hud-hover" : "bg-surface-2/60"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-2xs uppercase tracking-widest text-faint",
							children: label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("font-display text-lg font-semibold tabular-nums leading-none", isToday ? "text-fg" : "text-muted"),
							children: date
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-0.5",
							children: routine.quests.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full", day.quests[q.id]?.completed ? "bg-accent" : "bg-border") }, q.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-2xs tabular-nums text-faint",
							children: [
								done,
								"/",
								routine.quests.length
							]
						})
					]
				}, key);
			})
		})]
	});
}
function HunterApp() {
	const hydrated = useHunterStore((s) => s.hydrated);
	const persistApi = useHunterStore.persist;
	(0, import_react.useEffect)(() => {
		Promise.resolve(persistApi.rehydrate()).then(() => {
			useHunterStore.getState().hydrate();
		});
	}, [persistApi]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HazardStripe, { animated: true }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full max-w-6xl flex-1 flex-col gap-6 px-4 py-6 sm:px-6 sm:py-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}), hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadedBoard, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardSkeleton, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mx-auto flex w-full max-w-6xl flex-col gap-3 px-4 pb-6 sm:flex-row sm:items-center sm:justify-between sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xl text-sm text-faint",
					children: "Goals live in JSON. Progress stays on this device — export a save file whenever you want a backup."
				}), hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTools, {}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HazardStripe, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankUpModal, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "bottom-right",
				visibleToasts: 2,
				toastOptions: {
					duration: 2800,
					className: "!bg-surface !text-fg !border-border font-sans !rounded-md"
				}
			})
		]
	});
}
function Header() {
	const today = todayKey();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "stagger-in flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-2xs uppercase tracking-hud text-accent",
			children: routine.tagline
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-1 font-display text-4xl font-semibold tracking-tight text-fg sm:text-5xl",
			children: routine.name
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs uppercase tracking-widest text-muted",
			children: formatLongDate(today)
		})]
	});
}
function LoadedBoard() {
	const today = ensureDay(useHunterStore((s) => s.days), todayKey());
	const cleared = routine.quests.filter((q) => today.quests[q.id]?.completed).length;
	const allDone = dayFullyCleared(today);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerWindow, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs uppercase tracking-hud text-accent",
					children: "Daily quests"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold tracking-tight",
					children: allDone ? "Gate cleared" : "Today's objectives"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs tabular-nums uppercase tracking-widest text-muted",
					children: [
						cleared,
						" / ",
						routine.quests.length,
						" complete"
					]
				})]
			}),
			allDone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-4 rounded-md bg-surface px-4 py-3 font-mono text-2xs uppercase tracking-widest text-accent shadow-hud-hover",
				children: [
					"Daily clear bonus claimed · +",
					routine.dailyClearBonus,
					" XP"
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: routine.quests.map((quest, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestCard, {
					quest,
					index
				}, quest.id))
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekLog, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsRow, {})
	] });
}
function StatsRow() {
	const xp = useHunterStore((s) => s.xp);
	const days = useHunterStore((s) => s.days);
	const clearedDays = Object.values(days).filter((d) => d.bonusClaimed).length;
	const quests = Object.values(days).reduce((n, d) => {
		return n + Object.values(d.quests).filter((q) => q.completed).length;
	}, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stagger-in grid grid-cols-3 gap-2 sm:gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
				label: "Total XP",
				value: xp.toLocaleString()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
				label: "Days cleared",
				value: String(clearedDays)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
				label: "Quests done",
				value: String(quests)
			})
		]
	});
}
function MiniStat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-surface px-3 py-3 shadow-hud sm:px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-2xs uppercase tracking-widest text-faint",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-display text-2xl font-semibold tabular-nums leading-none text-fg",
			children: value
		})]
	});
}
function BoardSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 rounded-lg bg-surface shadow-hud" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-52 rounded-lg bg-surface shadow-hud" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-52 rounded-lg bg-surface shadow-hud" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-52 rounded-lg bg-surface shadow-hud" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-52 rounded-lg bg-surface shadow-hud" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-36 rounded-lg bg-surface shadow-hud" })
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HunterApp, {});
}
//#endregion
export { Home as component };
